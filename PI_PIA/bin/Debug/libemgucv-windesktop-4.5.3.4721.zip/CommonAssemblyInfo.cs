using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyVersion("4.5.3.4721")]
[assembly: AssemblyFileVersion("4.5.3.4721")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Emgu Corporation")]
[assembly: AssemblyProduct("Emgu.CV")]
[assembly: AssemblyCopyright("Copyright Emgu Corporation 2021")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
